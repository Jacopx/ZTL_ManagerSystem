package it.polito.dp2.RNS.sol3.service.service;

/**
 * Copyright by Jacopx on 2019-01-17.
 */
public enum SearchVehicles {
    ALL,
    CAR,
    TRUCK,
    SHUTTLE,
    CARAVAN
}
